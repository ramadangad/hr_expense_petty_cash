* `Ecosoft <http://ecosoft.co.th>`__:

  * Pimolnat Suntian <pimolnats@ecosoft.co.th>
  * Saran Lim. <saranl@ecosoft.co.th>

* `Trinityroots <http://trinityroots.co.th>`__:

  * Santi Techatoo <santi.tec@trinityroots.co.th>
