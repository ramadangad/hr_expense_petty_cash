# Copyright 2019 Ecosoft Co., Ltd. (http://ecosoft.co.th)
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from odoo import api, fields, Command, models, _

from odoo.exceptions import  ValidationError
from odoo.tools import float_compare



class HrExpenseSheet(models.Model):
    _inherit = "hr.expense.sheet"

    petty_cash_id = fields.Many2one(
        string="Petty cash holder",
        comodel_name="petty.cash",
        ondelete="restrict",
        compute="_compute_petty_cash",
    )

    @api.depends("expense_line_ids", "payment_mode")
    def _compute_petty_cash(self):
        for rec in self:
            rec.petty_cash_id = False
            if rec.payment_mode == "petty_cash":
                set_petty_cash_ids = set()
                for line in rec.expense_line_ids:
                    set_petty_cash_ids.add(line.petty_cash_id.id)
                if len(set_petty_cash_ids) == 1:
                    rec.petty_cash_id = rec.env["petty.cash"].browse(
                        set_petty_cash_ids.pop()
                    )
                    journal_petty_cash = rec.petty_cash_id.journal_id
                    if journal_petty_cash:
                        rec.journal_id = journal_petty_cash
                else:
                    raise ValidationError(
                        _("You cannot create report from many petty cash holders.")
                    )

    @api.constrains("expense_line_ids", "total_amount")
    def _check_petty_cash_amount(self):
        for rec in self:
            if rec.payment_mode == "petty_cash":
                petty_cash = rec.petty_cash_id
                balance = petty_cash.petty_cash_balance
                amount = rec.total_amount
                company_currency = rec.company_id.currency_id
                amount_company = rec.currency_id._convert(
                    amount,
                    company_currency,
                    rec.company_id,
                    rec.accounting_date or fields.Date.today(),
                )
                prec = rec.currency_id.rounding
                if float_compare(amount_company, balance, precision_rounding=prec) == 1:
                    raise ValidationError(
                        _(
                            "Not enough money in petty cash holder.\n"
                            "You are requesting {amount_company}{symbol}, "
                            "but the balance is {balance}{symbol}."
                        ).format(
                            amount_company="{:,.2f}".format(amount_company),
                            symbol=company_currency.symbol,
                            balance="{:,.2f}".format(balance - amount),
                        )
                    )

    def action_sheet_move_create(self):
        if self.payment_mode == "petty_cash":
            self.pt_action_sheet_move_create()
        else:
            super(HrExpenseSheet, self).action_sheet_move_create()


    def get_line_sh(self, data):
        line_list = []
        for x in data:
           line_list.append((0, 0, x[2]))
        return line_list

    def pt_action_sheet_move_create(self):
        data = self._prepare_move_vals()
        rec = self.env['account.move'].create({
            'move_type': 'in_invoice',
            'date': data['date'],
            'invoice_date': data['date'],
            'invoice_date_due': data['date'],
            'partner_id': self.petty_cash_id.partner_id.id,
            'journal_id': self.journal_id.id,
            'invoice_line_ids': self.get_line_sh(data['line_ids'])
        })

        rec.move_type = 'entry'
        rec.journal_id = self.journal_id.id,
        for x in rec.line_ids:
            if x.credit > 0:
                x.write({'account_id': self.petty_cash_id.account_id.id})
        self.account_move_id = rec.id
        self.state = 'done'
        self.account_move_id = rec.id
        rec.action_post()
        self.payment_state = 'paid'


    def action_open_account_move(self):
        self.ensure_one()
        return {
            'name': self.account_move_id.name,
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'views': [[False, "form"]],
            'res_model': 'account.move' if self.payment_mode in ['own_account', 'petty_cash'] else 'account.payment',
            'res_id': self.account_move_id.id if self.payment_mode in ['own_account', 'petty_cash'] else self.account_move_id.payment_id.id,
        }


